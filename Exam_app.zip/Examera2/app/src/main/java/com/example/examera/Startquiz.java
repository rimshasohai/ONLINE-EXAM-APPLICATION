package com.example.examera;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;


public class Startquiz extends AppCompatActivity {
    public boolean done;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_startquiz);
        Button buttonStartQuiz = findViewById(R.id.button_start_quiz);
        buttonStartQuiz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!Quiz.done){
                    startQuiz();
                    finish();
            }
                else{
                    Toast.makeText(Startquiz.this,"You have already completed this quiz, you scored " + Quiz.score, Toast.LENGTH_LONG).show();
                }
        }});
    }

    private void startQuiz() {
        Intent intent = new Intent(this, Quiz.class);
        startActivity(intent);
    }
}

