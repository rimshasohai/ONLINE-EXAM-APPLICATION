package com.example.examera;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private EditText edittextemailid;
    private EditText edittextpassword;
    private Button btn2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edittextemailid = (EditText) findViewById(R.id.et_edittextEMAILID);
        edittextpassword = (EditText) findViewById(R.id.et_edittextPASSWORD);
        btn2 = (Button) findViewById(R.id.btn_button);
        btn2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                if (edittextemailid.getText().length() > 0 && edittextpassword.getText().length() > 0){
                    Intent intent=new Intent(MainActivity.this,MainActivity2.class);
                    startActivity(intent);
                }
                else {
                    Toast.makeText(MainActivity.this,"SIGN IN UNSUCCESSFULLY", Toast.LENGTH_LONG).show();
                }

            }
        });
    }
}