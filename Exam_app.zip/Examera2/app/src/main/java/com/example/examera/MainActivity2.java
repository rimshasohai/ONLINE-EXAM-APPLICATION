package com.example.examera;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.Button;


import java.util.List;

public class MainActivity2 extends AppCompatActivity {
    private Button btn4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        btn4 = (Button) findViewById(R.id.buttonQuiz);

        setTitle("Quizzes");
        btn4.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainActivity2.this,Startquiz.class);
                startActivity(intent);
            }
        });
    }
}